document.addEventListener('DOMContentLoaded', () => {
    const listEl = document.getElementById('list');
    const blockedCountEl = document.getElementById('blockedCount');
    const inputDomainEl = document.getElementById('inputDomain');
    const btnAddEl = document.getElementById('btnAdd');
    const validationMsgEl = document.getElementById('validationMessage');
    const searchBarEl = document.getElementById('searchBar');
    const emptyStateEl = document.getElementById('emptyState');
    const btnClearAllEl = document.getElementById('btnClearAll');
    
    // Modal Elements
    const confirmModalEl = document.getElementById('confirmModal');
    const btnModalCancelEl = document.getElementById('btnModalCancel');
    const btnModalConfirmEl = document.getElementById('btnModalConfirm');
    
    // Toast Container
    const toastContainerEl = document.getElementById('toastContainer');

    let currentBlocklist = [];

    // ── LOGIC UTILS ──

    // Toast Notification
    function showToast(message, type = 'success') {
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        
        let icon = '✓';
        if (type === 'error') icon = '❌';
        else if (type === 'info') icon = 'ℹ️';

        toast.innerHTML = `<span>${icon}</span> <span>${message}</span>`;
        toastContainerEl.appendChild(toast);

        // Animate in
        setTimeout(() => toast.classList.add('show'), 50);

        // Remove after 3 seconds
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }

    // Helper to extract clean domain from user inputs (removes https://, paths, ports, query parameters)
    function cleanDomain(input) {
        let domain = input.trim().toLowerCase();
        
        if (domain.startsWith('http://') || domain.startsWith('https://')) {
            try {
                domain = new URL(domain).hostname;
            } catch (e) {
                // Parse manually if URL constructor fails
                domain = domain.replace(/^(https?:\/\/)?(www\.)?/, '');
            }
        }
        
        // Remove port, paths, and trailing slashes
        domain = domain.replace(/:\d+$/, '').split('/')[0];
        
        return domain;
    }

    // Validate domain format
    function isValidDomain(domain) {
        const domainRegex = /^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z0-9][a-z0-9-]{0,61}[a-z0-9]$/i;
        return domainRegex.test(domain);
    }

    // ── STORAGE & RENDER ──

    function updateStats(count) {
        blockedCountEl.textContent = count;
        if (count > 0) {
            btnClearAllEl.style.display = 'block';
        } else {
            btnClearAllEl.style.display = 'none';
        }
    }

    // Render list based on search/filter query
    function renderList(blocklist, filterQuery = '') {
        listEl.innerHTML = '';
        const filteredList = blocklist.filter(url => 
            url.toLowerCase().includes(filterQuery.toLowerCase())
        );

        updateStats(blocklist.length);

        if (filteredList.length === 0) {
            emptyStateEl.style.display = 'flex';
            if (filterQuery) {
                emptyStateEl.querySelector('.empty-title').textContent = 'Situs tidak ditemukan';
                emptyStateEl.querySelector('.empty-desc').textContent = `Tidak ada hasil pencarian untuk "${filterQuery}".`;
            } else {
                emptyStateEl.querySelector('.empty-title').textContent = 'Aman dari Judi Online';
                emptyStateEl.querySelector('.empty-desc').textContent = 'Tidak ada situs yang diblokir saat ini. Anda dapat menambahkan domain secara manual di atas.';
            }
            return;
        }

        emptyStateEl.style.display = 'none';

        filteredList.forEach(url => {
            const li = document.createElement('li');
            li.className = 'list-item';
            
            // Left container: Favicon & Domain
            const leftDiv = document.createElement('div');
            leftDiv.className = 'list-item-left';

            // Favicon with fallback
            const faviconWrapper = document.createElement('div');
            faviconWrapper.className = 'site-favicon';
            
            const firstLetter = url.charAt(0);
            const fallbackSpan = document.createElement('span');
            fallbackSpan.className = 'site-favicon-fallback';
            fallbackSpan.textContent = firstLetter;

            const img = document.createElement('img');
            img.src = `https://www.google.com/s2/favicons?sz=64&domain=${url}`;
            img.alt = '';
            img.onload = () => {
                faviconWrapper.appendChild(img);
            };
            img.onerror = () => {
                faviconWrapper.appendChild(fallbackSpan);
            };

            const domainSpan = document.createElement('span');
            domainSpan.className = 'site-domain';
            domainSpan.textContent = url;

            leftDiv.appendChild(faviconWrapper);
            leftDiv.appendChild(domainSpan);

            // Right container: Delete Button
            const deleteBtn = document.createElement('button');
            deleteBtn.className = 'btn-delete';
            deleteBtn.title = 'Hapus dari daftar blokir';
            
            // Trash SVG Icon
            deleteBtn.innerHTML = `
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                    <polyline points="3 6 5 6 21 6"></polyline>
                    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                    <line x1="10" y1="11" x2="10" y2="17"></line>
                    <line x1="14" y1="11" x2="14" y2="17"></line>
                </svg>
            `;

            deleteBtn.addEventListener('click', () => {
                // Add fade out animation first
                li.classList.add('item-fade-out');
                
                // Wait for animation to finish before updating storage
                setTimeout(() => {
                    currentBlocklist = currentBlocklist.filter(u => u !== url);
                    chrome.storage.local.set({ blocklist: currentBlocklist }, () => {
                        renderList(currentBlocklist, searchBarEl.value);
                        showToast(`Blokir untuk ${url} berhasil dihapus.`, 'info');
                    });
                }, 250);
            });

            li.appendChild(leftDiv);
            li.appendChild(deleteBtn);
            listEl.appendChild(li);
        });
    }

    // Load initial list from local storage
    chrome.storage.local.get(['blocklist'], (data) => {
        currentBlocklist = data.blocklist || [];
        renderList(currentBlocklist);
    });

    // ── INTERACTIONS ──

    // Add Domain manually
    function addDomain() {
        const rawInput = inputDomainEl.value;
        if (!rawInput.trim()) return;

        const url = cleanDomain(rawInput);

        if (!isValidDomain(url)) {
            inputDomainEl.classList.add('invalid');
            validationMsgEl.style.display = 'block';
            showToast('Format nama domain tidak valid!', 'error');
            return;
        }

        // Hide validation messages on successful validation
        inputDomainEl.classList.remove('invalid');
        validationMsgEl.style.display = 'none';

        if (currentBlocklist.includes(url)) {
            showToast(`Domain "${url}" sudah ada di dalam daftar blokir!`, 'error');
            return;
        }

        currentBlocklist.unshift(url); // Add to the top of the list
        chrome.storage.local.set({ blocklist: currentBlocklist }, () => {
            inputDomainEl.value = '';
            searchBarEl.value = ''; // Reset search on new addition
            renderList(currentBlocklist);
            showToast(`Domain "${url}" berhasil ditambahkan ke daftar blokir.`, 'success');
        });
    }

    btnAddEl.addEventListener('click', addDomain);
    inputDomainEl.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') addDomain();
    });

    // Reset validation border on keydown
    inputDomainEl.addEventListener('input', () => {
        inputDomainEl.classList.remove('invalid');
        validationMsgEl.style.display = 'none';
    });

    // Live search filter
    searchBarEl.addEventListener('input', (e) => {
        renderList(currentBlocklist, e.target.value);
    });

    // ── MODAL DIALOGS & ACTIONS ──

    // Clear All Trigger
    btnClearAllEl.addEventListener('click', () => {
        confirmModalEl.classList.add('active');
    });

    // Close Modal Cancellation
    function closeModal() {
        confirmModalEl.classList.remove('active');
    }

    btnModalCancelEl.addEventListener('click', closeModal);
    confirmModalEl.addEventListener('click', (e) => {
        if (e.target === confirmModalEl) {
            closeModal();
        }
    });

    // Confirm Clear All Actions
    btnModalConfirmEl.addEventListener('click', () => {
        currentBlocklist = [];
        chrome.storage.local.set({ blocklist: [] }, () => {
            renderList([]);
            closeModal();
            showToast('Seluruh daftar blokir berhasil dibersihkan.', 'success');
        });
    });

});
