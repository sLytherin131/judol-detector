const KOMDIGI_URL = 'https://aduankonten.id/'

// ── INIT ──
document.addEventListener('DOMContentLoaded', async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
    const url   = new URL(tab.url).hostname

    // Load state toggle
    chrome.storage.local.get(['isActive', 'sensorActive'], (data) => {
        setToggle('toggleExtension', data.isActive    || false)
        setToggle('toggleSensor',    data.sensorActive || false)
    })

    // Load hasil deteksi tab ini
    chrome.runtime.sendMessage(
        { type: 'GET_RESULT', tabId: tab.id },
        (result) => {
            if (chrome.runtime.lastError) return; // Abaikan error jika background belum siap
            if (result) showResult(result);
        }
    )

    // Toggle ekstensi
    document.getElementById('toggleExtension').addEventListener('change', (e) => {
        const next = e.target.checked
        chrome.storage.local.set({ isActive: next })
        chrome.tabs.sendMessage(tab.id, { type: 'TOGGLE_EXTENSION', active: next }).catch(() => {
            // Halaman internal chrome, abaikan
        })
    })

    // Toggle sensor
    document.getElementById('toggleSensor').addEventListener('change', (e) => {
        const next = e.target.checked
        chrome.storage.local.set({ sensorActive: next })
        chrome.tabs.sendMessage(tab.id, { type: 'TOGGLE_SENSOR', active: next }).catch(() => {
            console.warn('Halaman ini tidak mendukung sensor (mungkin chrome:// atau halaman internal).');
        })
    })

    // Tombol aksi
    document.getElementById('btnBlock').addEventListener('click', () => {
        chrome.runtime.sendMessage({ type: 'BLOCK_SITE', url }, () => {
            if (chrome.runtime.lastError) return;
        })
        window.close()
    })

    document.getElementById('btnReport').addEventListener('click', () => {
        chrome.tabs.create({ url: KOMDIGI_URL })
    })

    document.getElementById('btnContinue').addEventListener('click', () => {
        chrome.tabs.sendMessage(tab.id, { type: 'START_SENSOR_SCAN' }).catch(() => {})
        window.close()
    })

    document.getElementById('linkBlocklist').addEventListener('click', () => {
        chrome.tabs.create({ url: chrome.runtime.getURL('blocklist/blocklist.html') })
    })
})

// ── HELPERS ──
function setToggle(id, active) {
    const el = document.getElementById(id)
    if (el) {
        el.checked = active
    }
}

function showResult(result) {
    document.getElementById('resultCard').style.display = 'block'

    const pct = (v) => Math.round(v * 100)

    document.getElementById('confImage').textContent  = pct(result.confidence_image)  + '%'
    document.getElementById('confText').textContent   = pct(result.confidence_text)   + '%'
    document.getElementById('confFusion').textContent = pct(result.confidence_fusion) + '%'
    document.getElementById('confFinal').textContent  = pct(result.final_confidence)  + '%'

    document.getElementById('barImage').style.width   = pct(result.confidence_image)  + '%'
    document.getElementById('barText').style.width    = pct(result.confidence_text)   + '%'
    document.getElementById('barFusion').style.width  = pct(result.confidence_fusion) + '%'
    document.getElementById('barFinal').style.width   = pct(result.final_confidence)  + '%'

    if (result.is_judol) {
        document.getElementById('warningBanner').style.display = 'block'
        document.getElementById('confidenceText').textContent  =
            `Tingkat keyakinan: ${pct(result.final_confidence)}%`
        document.getElementById('actionButtons').style.display = 'flex'
    }
}
