// ── EKSTRAKSI TEKS ──
function extractText() {
    const title       = document.title || ''
    const meta        = document.querySelector('meta[name="description"]')?.content || ''
    const headings    = [...document.querySelectorAll('h1, h2, h3')]
                            .map(h => h.innerText).join(' ')
    const paragraphs  = [...document.querySelectorAll('p')]
                            .map(p => p.innerText.trim())
                            .filter(t => t.length > 10)   // buang paragraf terlalu pendek
                            .slice(0, 5)                  // ambil 5 paragraf pertama saja
                            .join(' ')
    const anchors     = [...document.querySelectorAll('a')]
                            .map(a => a.innerText).join(' ')

    return [title, meta, headings, paragraphs, anchors]
        .join(' ')
        .replace(/\s+/g, ' ')
        .trim()
        .slice(0, 512)  // batas token IndoBERT
}

// Kata kunci judol yang cukup dideteksi dari alt text / teks halaman
const JUDOL_KEYWORDS = [
    'slot gacor', 'maxwin', 'togel', 'judi online', 'situs judi',
    'daftar sekarang', 'bonus member', 'jackpot', 'scatter', 'withdraw',
    'rtp tertinggi', 'rtp tinggi', 'rtp slot', 'link alternatif', 'deposit',
    'bocoran slot', 'slot online', 'agen slot', 'agen togel', 'bandar togel',
    'bandar judi', 'casino online', 'pragmatic play', 'pg soft', 'habanero',
    'asupantoto', 'slot88', 'gacor77', 'olympus'
]

// Cek apakah teks mengandung kata kunci judol
function containsJudolKeyword(text) {
    if (!text) return false
    const lower = text.toLowerCase()
    return JUDOL_KEYWORDS.some(kw => lower.includes(kw))
}

// ── EKSTRAKSI GAMBAR (mendukung lazy-load & CSS sizing) ──
function extractImages() {
    const imgs = [...document.querySelectorAll('img, [data-src], [data-lazy], [data-lazy-src], [data-original]')]

    const result = []
    const seen   = new Set()

    for (const img of imgs) {
        // Ambil URL gambar — coba src asli, lalu atribut lazy-load
        const src = img.src ||
                    img.dataset.src ||
                    img.dataset.lazy ||
                    img.dataset.lazySrc ||
                    img.dataset.original || ''

        if (!src.startsWith('http')) continue
        if (seen.has(src))           continue
        if (src.includes('favicon')) continue

        // Filter logo/avatar kecuali namanya sangat jelas judol
        const altText = (img.alt || '').toLowerCase()
        const isObviouslyJudol = containsJudolKeyword(altText) || containsJudolKeyword(src)
        if (!isObviouslyJudol) {
            if (src.includes('logo') || src.includes('avatar')) continue
        }

        // Dimensi: coba naturalWidth → layout CSS → getBoundingClientRect
        let w = img.naturalWidth  || img.width
        let h = img.naturalHeight || img.height
        if ((!w || !h) && img.getBoundingClientRect) {
            const rect = img.getBoundingClientRect()
            w = w || Math.round(rect.width)
            h = h || Math.round(rect.height)
        }

        // Loloskan jika:
        // (a) dimensi cukup besar (sudah diketahui)
        // (b) ATAU alt text/src mengandung kata judol (prioritas tinggi)
        // (c) ATAU dimensi belum diketahui tapi URL terlihat seperti gambar konten
        const dimensiCukup  = w >= 100 && h >= 50
        const dimensiUnknown = w === 0 && h === 0
        const isContentImage = /\.(jpg|jpeg|png|webp|gif|avif)(\?|$)/i.test(src)

        if (!dimensiCukup && !isObviouslyJudol && !( dimensiUnknown && isContentImage)) continue

        seen.add(src)
        result.push({
            src        : src,
            alt        : img.alt || '',
            w          : w,
            h          : h,
            altIsJudol : isObviouslyJudol
        })

        if (result.length >= 10) break  // maksimal 10 gambar
    }

    return result
}

// ── KONVERSI GAMBAR KE BASE64 (Melalui background script untuk bypass CORS) ──
async function imageUrlToBase64(url) {
    return new Promise((resolve) => {
        chrome.runtime.sendMessage({ type: 'CONVERT_TO_BASE64', url: url }, (response) => {
            resolve(response && response.base64 ? response.base64 : null);
        });
    });
}

// ── CEK APAKAH HALAMAN INI ADALAH SEARCH ENGINE RESULTS PAGE (SERP) ──
function isSearchEnginePage() {
    const hostname = window.location.hostname.toLowerCase()
    const params   = new URLSearchParams(window.location.search)

    // Daftar domain search engine utama
    const searchDomains = [
        'google.com', 'google.co.id', 'google.co.uk', 'google.com.au',
        'bing.com',
        'search.yahoo.com', 'yahoo.com',
        'duckduckgo.com',
        'yandex.com', 'yandex.ru',
        'baidu.com',
        'ask.com',
        'ecosia.org',
        'search.brave.com',
        'startpage.com',
        'searx.me',
        'search.naver.com',
        'daum.net',
    ]

    // Cocokkan hostname (termasuk subdomain, misal www.google.com)
    const isSearchDomain = searchDomains.some(domain =>
        hostname === domain || hostname.endsWith('.' + domain)
    )

    if (!isSearchDomain) return false

    // Hanya skip jika ada parameter query pencarian aktif
    const hasQuery = params.has('q') || params.has('query') ||
                     params.has('search') || params.has('text') ||
                     params.has('p') || params.has('wd')

    return hasQuery
}

// ── KIRIM DATA KE BACKGROUND ──
async function collectAndSend() {
    // Jangan scan halaman hasil pencarian (SERP) search engine
    if (isSearchEnginePage()) {
        console.log('[Judol Detector] Halaman search engine terdeteksi, scan dilewati.')
        return
    }

    const text   = extractText()
    const images = extractImages()

    // Prioritaskan gambar yang alt-nya mengandung kata judol, lalu urutkan dari terbesar
    const sorted = images.sort((a, b) => {
        if (a.altIsJudol && !b.altIsJudol) return -1
        if (!a.altIsJudol && b.altIsJudol) return 1
        return (b.w * b.h) - (a.w * a.h)
    })
    const top3Images = sorted.slice(0, 3)

    // Konversi ketiga gambar ke base64 secara paralel
    const base64Promises = top3Images.map(img => imageUrlToBase64(img.src))
    const base64Results  = await Promise.all(base64Promises)
    const validBase64s   = base64Results.filter(b64 => b64 !== null)

    chrome.runtime.sendMessage({
        type     : 'PAGE_DATA',
        url      : window.location.href,
        text     : text,
        mainImage: validBase64s[0] || null, // Untuk backward compatibility
        images   : validBase64s,            // List base64 dari 3 gambar terbesar
        allImages: images.map(img => img.src)
    }).catch(err => {
        console.warn('[Judol Detector] Gagal mengirim PAGE_DATA ke background script:', err.message);
    });
}

// ── STATE ──
let isPageJudol = false;

// ── TERIMA PESAN DARI BACKGROUND/POPUP ──
chrome.runtime.onMessage.addListener((message) => {
    if (message.type === 'PAGE_RESULT') {
        isPageJudol = message.result.is_judol;
        if (isPageJudol) {
            showFloatingWarning(message.result)
            chrome.storage.local.get(['isActive', 'sensorActive'], (data) => {
                if (data.isActive && data.sensorActive) {
                    scanAndBlurImages();
                }
            });
        }
    }

    if (message.type === 'SHOW_WARNING') { // Fallback if still sent
        isPageJudol = true;
        showFloatingWarning(message.result)
    }

    if (message.type === 'START_SENSOR_SCAN') {
        if (isPageJudol) scanAndBlurImages()
    }

    if (message.type === 'TOGGLE_SENSOR') {
        if (!message.active) {
            removeAllBlur()
        } else {
            if (isPageJudol) scanAndBlurImages()
        }
    }

    if (message.type === 'TOGGLE_EXTENSION') {
        if (!message.active) {
            // Hapus banner warning jika ada
            const warningBanner = document.getElementById('judol-warning-banner');
            if (warningBanner) warningBanner.remove();
            
            // Hapus semua blur
            removeAllBlur();
            isPageJudol = false; // Reset state
        } else {
            // Jalankan ulang deteksi halaman
            collectAndSend();
        }
    }
})

// ── TAMPILKAN WARNING FLOATING DI HALAMAN ──
function showFloatingWarning(result) {
    // Jika sudah ada banner, jangan buat lagi (mencegah race condition)
    const existing = document.getElementById('judol-warning-banner');
    if (existing) return; // sudah tampil

    const pct = (v) => Math.round(v * 100);
    const pctFinal = pct(result.final_confidence);
    const pctImage = pct(result.confidence_image);
    const pctText = pct(result.confidence_text);
    const pctFusion = pct(result.confidence_fusion);

    const overlay = document.createElement('div');
    overlay.id = 'judol-warning-banner';
    overlay.style.cssText = `
        position: fixed !important;
        top: 0 !important;
        left: 0 !important;
        width: 100vw !important;
        height: 100vh !important;
        background: rgba(15, 23, 42, 0.4) !important;
        backdrop-filter: blur(8px) !important;
        -webkit-backdrop-filter: blur(8px) !important;
        z-index: 2147483647 !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif !important;
        box-sizing: border-box !important;
        opacity: 0 !important;
        transition: opacity 0.25s ease !important;
    `;

    overlay.innerHTML = `
        <style>
            #judol-det-btn-close:hover {
                color: #ef4444 !important;
            }
            #judol-det-btn-block:hover {
                transform: translateY(-1px) !important;
                box-shadow: 0 6px 16px rgba(16, 185, 129, 0.3) !important;
                background: linear-gradient(135deg, #34d399 0%, #059669 100%) !important;
            }
            #judol-det-btn-block:active {
                transform: translateY(1px) !important;
            }
            #judol-det-btn-report:hover {
                transform: translateY(-1px) !important;
                box-shadow: 0 6px 16px rgba(245, 158, 11, 0.25) !important;
            }
            #judol-det-btn-report:active {
                transform: translateY(1px) !important;
            }
            #judol-det-btn-continue:hover {
                transform: translateY(-1px) !important;
                box-shadow: 0 6px 16px rgba(239, 68, 68, 0.3) !important;
                background: linear-gradient(135deg, #f87171 0%, #dc2626 100%) !important;
                color: white !important;
            }
            #judol-det-btn-continue:active {
                transform: translateY(1px) !important;
            }
        </style>
        <div id="judol-detector-card" style="
            position: relative !important;
            background: #ffffff !important;
            border: 1px solid rgba(0, 0, 0, 0.08) !important;
            border-radius: 20px !important;
            width: 360px !important;
            max-width: 90% !important;
            padding: 24px !important;
            box-shadow: 0 20px 40px rgba(15, 23, 42, 0.12) !important;
            color: #0f172a !important;
            display: flex !important;
            flex-direction: column !important;
            gap: 16px !important;
            box-sizing: border-box !important;
            text-align: left !important;
            font-family: inherit !important;
        ">
            <!-- Close Button -->
            <button id="judol-det-btn-close" style="
                position: absolute !important;
                top: 16px !important;
                right: 16px !important;
                background: transparent !important;
                border: none !important;
                font-size: 16px !important;
                font-weight: bold !important;
                color: #94a3b8 !important;
                cursor: pointer !important;
                padding: 4px !important;
                transition: color 0.2s ease !important;
                outline: none !important;
            ">✕</button>

            <!-- Header -->
            <div style="display: flex !important; flex-direction: column !important; align-items: center !important; text-align: center !important; margin-bottom: 4px !important;">
                <div style="position: relative !important; margin-bottom: 12px !important; display: flex !important; justify-content: center !important; align-items: center !important;">
                    <div style="position: absolute !important; width: 64px !important; height: 64px !important; background: #ef4444 !important; filter: blur(12px) !important; opacity: 0.15 !important; border-radius: 50% !important;"></div>
                    <div style="font-size: 32px !important; position: relative !important; z-index: 2 !important;">⚠️</div>
                </div>
                <h2 style="font-size: 17px !important; font-weight: 800 !important; margin: 0 !important; color: #ef4444 !important; text-transform: uppercase !important; letter-spacing: 0.05em !important; font-family: inherit !important;">Terdeteksi Promosi Judol</h2>
                <p style="font-size: 12.5px !important; color: #64748b !important; margin: 6px 0 0 0 !important; font-weight: 700 !important; font-family: inherit !important;">
                    Tingkat keyakinan: ${pctFinal}%
                </p>
            </div>

            <!-- Metrics -->
            <div style="
                background: #f8fafc !important;
                border: 1px solid #e2e8f0 !important;
                border-radius: 14px !important;
                padding: 16px !important;
                display: flex !important;
                flex-direction: column !important;
                gap: 12px !important;
                box-sizing: border-box !important;
            ">
                <div style="font-size: 10.5px !important; font-weight: 800 !important; color: #64748b !important; text-transform: uppercase !important; letter-spacing: 0.08em !important; border-bottom: 1px solid #e2e8f0 !important; padding-bottom: 8px !important; margin-bottom: 4px !important; font-family: inherit !important;">Hasil Deteksi Halaman</div>
                
                <!-- Analisis Gambar -->
                <div>
                    <div style="display: flex !important; justify-content: space-between !important; font-size: 11.5px !important; font-weight: 700 !important; color: #475569 !important; margin-bottom: 5px !important; font-family: inherit !important;">
                        <span>Analisis Gambar</span>
                        <span>${pctImage}%</span>
                    </div>
                    <div style="height: 6px !important; background: rgba(0, 0, 0, 0.05) !important; border-radius: 4px !important; overflow: hidden !important;">
                        <div style="height: 100% !important; border-radius: 4px !important; width: ${pctImage}% !important; background: linear-gradient(90deg, #3b82f6, #60a5fa) !important;"></div>
                    </div>
                </div>

                <!-- Analisis Teks -->
                <div>
                    <div style="display: flex !important; justify-content: space-between !important; font-size: 11.5px !important; font-weight: 700 !important; color: #475569 !important; margin-bottom: 5px !important; font-family: inherit !important;">
                        <span>Analisis Teks</span>
                        <span>${pctText}%</span>
                    </div>
                    <div style="height: 6px !important; background: rgba(0, 0, 0, 0.05) !important; border-radius: 4px !important; overflow: hidden !important;">
                        <div style="height: 100% !important; border-radius: 4px !important; width: ${pctText}% !important; background: linear-gradient(90deg, #10b981, #34d399) !important;"></div>
                    </div>
                </div>

                <!-- Analisis Fusion -->
                <div>
                    <div style="display: flex !important; justify-content: space-between !important; font-size: 11.5px !important; font-weight: 700 !important; color: #475569 !important; margin-bottom: 5px !important; font-family: inherit !important;">
                        <span>Analisis Fusion</span>
                        <span>${pctFusion}%</span>
                    </div>
                    <div style="height: 6px !important; background: rgba(0, 0, 0, 0.05) !important; border-radius: 4px !important; overflow: hidden !important;">
                        <div style="height: 100% !important; border-radius: 4px !important; width: ${pctFusion}% !important; background: linear-gradient(90deg, #f59e0b, #fbbf24) !important;"></div>
                    </div>
                </div>

                <!-- Skor Akhir -->
                <div style="margin-top: 4px !important; padding-top: 8px !important; border-top: 1px dashed #e2e8f0 !important;">
                    <div style="display: flex !important; justify-content: space-between !important; font-size: 12px !important; font-weight: 800 !important; color: #ef4444 !important; margin-bottom: 6px !important; font-family: inherit !important;">
                        <span>Skor Akhir (Final)</span>
                        <span>${pctFinal}%</span>
                    </div>
                    <div style="height: 8px !important; background: rgba(0, 0, 0, 0.05) !important; border-radius: 4px !important; overflow: hidden !important;">
                        <div style="height: 100% !important; border-radius: 4px !important; width: ${pctFinal}% !important; background: linear-gradient(90deg, #ef4444, #f87171) !important;"></div>
                    </div>
                </div>
            </div>

            <!-- Action Buttons -->
            <div style="display: flex !important; flex-direction: column !important; gap: 8px !important; width: 100% !important;">
                <button id="judol-det-btn-block" style="
                    display: flex !important; align-items: center !important; justify-content: center !important; gap: 8px !important;
                    width: 100% !important; padding: 11px 16px !important; border: none !important; border-radius: 10px !important;
                    cursor: pointer !important; font-size: 13px !important; font-weight: 700 !important; color: white !important;
                    background: linear-gradient(135deg, #10b981 0%, #059669 100%) !important;
                    box-shadow: 0 4px 12px rgba(16, 185, 129, 0.2) !important;
                    transition: transform 0.1s ease, box-shadow 0.2s ease !important;
                    font-family: inherit !important;
                    outline: none !important;
                ">
                    <span>🚫</span> Blokir Situs Ini
                </button>
                <button id="judol-det-btn-report" style="
                    display: flex !important; align-items: center !important; justify-content: center !important; gap: 8px !important;
                    width: 100% !important; padding: 11px 16px !important; border: none !important; border-radius: 10px !important;
                    cursor: pointer !important; font-size: 13px !important; font-weight: 700 !important; color: white !important;
                    background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%) !important;
                    box-shadow: 0 4px 12px rgba(245, 158, 11, 0.15) !important;
                    transition: transform 0.1s ease, box-shadow 0.2s ease !important;
                    font-family: inherit !important;
                    outline: none !important;
                ">
                    <span>📢</span> Laporkan ke Komdigi
                </button>
                <button id="judol-det-btn-continue" style="
                    display: flex !important; align-items: center !important; justify-content: center !important; gap: 8px !important;
                    width: 100% !important; padding: 11px 16px !important; border: none !important; border-radius: 10px !important;
                    cursor: pointer !important; font-size: 13px !important; font-weight: 700 !important; color: white !important;
                    background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%) !important;
                    box-shadow: 0 4px 12px rgba(239, 68, 68, 0.2) !important;
                    transition: transform 0.1s ease, box-shadow 0.2s ease, background 0.2s ease !important;
                    font-family: inherit !important;
                    outline: none !important;
                ">
                    Lanjut Akses Situs
                </button>
            </div>
        </div>
    `;

    // Attach Event Listeners
    const removeModal = () => {
        overlay.style.opacity = '0';
        setTimeout(() => overlay.remove(), 250);
    };

    overlay.querySelector('#judol-det-btn-close').addEventListener('click', removeModal);
    
    overlay.querySelector('#judol-det-btn-continue').addEventListener('click', () => {
        removeModal();
        // Trigger sensor scan (blur)
        scanAndBlurImages();
    });

    overlay.querySelector('#judol-det-btn-block').addEventListener('click', () => {
        const url = window.location.hostname;
        chrome.runtime.sendMessage({ type: 'BLOCK_SITE', url: url }, () => {
            window.location.href = chrome.runtime.getURL('blocked.html');
        });
    });

    overlay.querySelector('#judol-det-btn-report').addEventListener('click', () => {
        window.open('https://aduankonten.id/', '_blank');
    });

    document.body.prepend(overlay);
    
    // Trigger transition fade-in
    setTimeout(() => {
        overlay.style.opacity = '1';
    }, 50);
}

// ── SCAN SEMUA GAMBAR & BLUR YANG TERDETEKSI JUDOL ──
async function scanAndBlurImages() {
    // Pastikan ekstensi aktif dan sensor aktif, DAN halaman adalah judol
    if (!isPageJudol) return;

    const storage = await new Promise(resolve => {
        chrome.storage.local.get(['isActive', 'sensorActive'], resolve);
    });
    if (!storage.isActive || !storage.sensorActive) {
        return;
    }

    const images = extractImages()  // Gunakan fungsi yang sudah diperbaiki

    for (const imgData of images) {
        // Cari elemen <img> yang sesuai di DOM
        const imgEl = document.querySelector(
            `img[src="${CSS.escape(imgData.src)}"],` +
            `img[data-src="${CSS.escape(imgData.src)}"],` +
            `img[data-lazy="${CSS.escape(imgData.src)}"]`
        ) || [...document.querySelectorAll('img')].find(
            el => (el.src || el.dataset.src || '') === imgData.src
        )

        if (!imgEl) continue

        try {
            // JALUR CEPAT: Jika alt text / URL sudah mengandung kata judol, langsung blur
            if (imgData.altIsJudol) {
                blurElement(imgEl)
                continue
            }

            const base64 = await imageUrlToBase64(imgData.src)
            if (!base64) continue

            // Proxy request ke background script untuk menghindari peringatan Local Network Access (LNA) di browser
            const result = await new Promise(resolve => {
                chrome.runtime.sendMessage({ type: 'PREDICT_IMAGE', base64: base64 }, response => {
                    resolve(response || { is_judol: false })
                })
            })

            if (result.is_judol) {
                blurElement(imgEl)
            }
        } catch (e) {
            // skip gambar yang tidak bisa diproses
        }
    }

    // Blur teks yang mengandung kata kunci judol
    blurJudolText()
}

// ── BLUR GAMBAR ──
function blurElement(el) {
    if (el.dataset.judolBlurred === "true") return;
    el.dataset.judolBlurred = "true";
    el.style.filter     = 'blur(12px) grayscale(100%)'
    el.style.transition = 'filter 0.3s'

    // Tambah overlay label
    const wrapper = document.createElement('div')
    wrapper.dataset.judolWrapper = "true";
    wrapper.style.cssText = `
        position: relative; display: inline-block;
    `
    const label = document.createElement('div')
    label.textContent = '🚫 Konten Disensor'
    label.style.cssText = `
        position: absolute; top: 50%; left: 50%;
        transform: translate(-50%, -50%);
        background: rgba(0,0,0,0.7); color: white;
        padding: 4px 10px; border-radius: 4px;
        font-size: 12px; pointer-events: none; z-index: 10;
    `
    el.parentNode.insertBefore(wrapper, el)
    wrapper.appendChild(el)
    wrapper.appendChild(label)
}

// ── BLUR TEKS JUDOL (kata kunci) ──
function blurJudolText() {
    const keywords = JUDOL_KEYWORDS  // Gunakan daftar kata kunci yang sama

    const walker = document.createTreeWalker(
        document.body,
        NodeFilter.SHOW_TEXT
    )

    const nodes = []
    while (walker.nextNode()) nodes.push(walker.currentNode)

    nodes.forEach(node => {
        const text  = node.textContent.toLowerCase()
        const found = keywords.some(kw => text.includes(kw))

        if (found && node.parentElement) {
            if (node.parentElement.dataset.judolTextBlurred === "true") return;
            node.parentElement.dataset.judolTextBlurred = "true";
            node.parentElement.style.filter = 'blur(4px)'
            node.parentElement.title        = 'Konten disensor oleh Judol Detector'
        }
    })
}

// ── HAPUS SEMUA BLUR ──
function removeAllBlur() {
    // 1. Kembalikan gambar yang di-blur dan di-wrap
    const blurredImages = document.querySelectorAll('[data-judol-blurred="true"]');
    blurredImages.forEach(el => {
        el.style.filter = '';
        el.style.transition = '';
        delete el.dataset.judolBlurred;

        // Cek apakah dibungkus oleh wrapper sensor
        const wrapper = el.parentNode;
        if (wrapper && wrapper.dataset.judolWrapper === "true") {
            const originalParent = wrapper.parentNode;
            if (originalParent) {
                // Kembalikan gambar ke tempat asalnya sebelum wrapper
                originalParent.insertBefore(el, wrapper);
                // Hapus wrapper beserta label sensor di dalamnya
                wrapper.remove();
            }
        }
    });

    // 2. Kembalikan teks yang di-blur
    const blurredTexts = document.querySelectorAll('[data-judol-text-blurred="true"]');
    blurredTexts.forEach(el => {
        el.style.filter = '';
        if (el.title === 'Konten disensor oleh Judol Detector') {
            el.removeAttribute('title');
        }
        delete el.dataset.judolTextBlurred;
    });
}

// ── OBSERVER: Tangkap gambar yang dimuat secara dinamis (lazy load / infinite scroll) ──
let _observerActive = false
function startImageObserver() {
    if (_observerActive) return
    _observerActive = true

    const observer = new MutationObserver(() => {
        if (!isPageJudol) return;
        chrome.storage.local.get(['isActive', 'sensorActive'], (data) => {
            if (data.isActive && data.sensorActive && !isSearchEnginePage()) {
                // Debounce agar tidak terlalu sering scan
                clearTimeout(window._judolObserverTimer)
                window._judolObserverTimer = setTimeout(() => {
                    scanAndBlurImages()
                }, 800)
            }
        })
    })

    observer.observe(document.body, {
        childList : true,
        subtree   : true,
        attributes: true,
        attributeFilter: ['src', 'data-src', 'data-lazy', 'data-lazy-src', 'data-original']
    })

    console.log('[Judol Detector] MutationObserver aktif — memantau gambar dinamis.')
}

// Jalankan pengumpulan data saat halaman selesai load
chrome.storage.local.get(['isActive'], (data) => {
    if (data.isActive !== false) {
        collectAndSend()
        // Coba lagi setelah 2 detik untuk gambar yang lambat load
        setTimeout(() => {
            chrome.storage.local.get(['isActive'], (d) => {
                if (d.isActive !== false) collectAndSend()
            })
        }, 2000)
    }
})

// Cek status global dan inisialisasi observer
chrome.storage.local.get(['isActive', 'sensorActive'], (data) => {
    if (data.isActive && data.sensorActive && !isSearchEnginePage()) {
        // Observer aktif sejak awal, tapi hanya akan memproses jika isPageJudol = true
        startImageObserver()
    }
})
